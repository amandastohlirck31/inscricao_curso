import 'package:flutter/material.dart';
import 'package:inscricaocurso/login.dart';
import 'package:url_launcher/url_launcher.dart'; // Importa o url_launcher
import 'telaformulario.dart';


void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'English In Action - Formulário de Inscrição',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        fontFamily: 'MinhaFonte',
      ),
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  // Método para abrir URL
  void _launchURL(String url) async {
    final Uri uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    } else {
      throw 'Não foi possível abrir o link $url';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF5F5F5),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          SizedBox(height: 50.0),

          Center(
            child: Container(
              width: MediaQuery.of(context).size.width * 0.8,
              padding: EdgeInsets.symmetric(vertical: 40.0),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF003366), Color(0xFFDA291C)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20.0),
              ),
              child: Center(
                child: Text(
                  'Curso English In Action',
                  style: TextStyle(
                    fontSize: 28.0,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ),

          SizedBox(height: 30.0),

          Center(
            child: Container(
              width: MediaQuery.of(context).size.width * 0.8,
              padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
              decoration: BoxDecoration(
                color: Color(0xFF003366),
                borderRadius: BorderRadius.circular(20.0),
              ),
              child: Column(
                children: [
                  Text(
                    'Descubra o mundo do inglês com nosso minicurso exclusivo!',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 18.0,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 20.0),
                  Text(
                    'Composto por 5 aulas dinâmicas, cada uma repleta de atividades práticas e dicas valiosas para aprimorar suas habilidades linguísticas. Este curso é projetado para todos os níveis de proficiência, oferecendo uma experiência imersiva e interativa que o ajudará a ganhar confiança e fluência na língua inglesa. Prepare-se para explorar novos horizontes linguísticos e alcançar seus objetivos de comunicação global!',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 16.0,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 20.0),
                  Container(
                    width: double.infinity,
                    padding: EdgeInsets.symmetric(horizontal: 16.0),
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => Login()),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        padding: EdgeInsets.symmetric(vertical: 16.0),
                        primary: Colors.blue,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20.0),
                        ),
                      ),
                      child: Text(
                        "Entrar",
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          Expanded(child: Container()),

          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Acompanhe nossas redes sociais: ',
                  style: TextStyle(fontSize: 18.0, color: Colors.black45),
                ),
                IconButton(
                  icon: Icon(Icons.photo_camera_outlined, color: Colors.black45),
                  onPressed: () {
                    print('Ícone clicado');
                    _launchURL('https://www.instagram.com/english_action_?igsh=OGs3eDV1cGp6N2wz');
                  },
                ),
                IconButton(
                  icon: Icon(Icons.attach_file, color: Colors.black45), // Ícone de clipe
                  onPressed: () {
                    _launchURL('https://englishinaction.github.io/englishinactionifrs/'); // Substitua pelo link desejado
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// Nova página do curso
class CoursePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Curso'),
      ),
      body: Center(
        child: Text(
          'Aqui vai a tela do curso que foi feita pela Júlia Dalanora',
          style: TextStyle(fontSize: 16.0),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}


