import 'package:flutter/material.dart';
import 'package:inscricaocurso/login.dart';

class User {
  String name;
  String email;
  String username;
  String password;

  User({required this.name, required this.email, required this.username, required this.password});
}

class UserDatabase {
  final List<User> _users = [];

  void addUser(User user) {
    _users.add(user);
  }

  List<User> getUsers() {
    return _users;
  }

  User? findUser(String username, String password) {
    return _users.firstWhere(
          (user) => user.username == username && user.password == password,
      orElse: () => User(name: 'N/A', email: 'N/A', username: 'N/A', password: 'N/A'), // Retorna um User padrão
    );
  }
}


class RegistrationScreen extends StatefulWidget {
  @override
  _RegistrationScreenState createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final formKey = GlobalKey<FormState>();
  bool isLoading = false;
  bool isTermsAccepted = false;

  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController usernameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  UserDatabase userDatabase = UserDatabase();

  void _openTerms() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Abrindo os Termos de Uso...")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: MediaQuery.of(context).size.height,
              decoration: BoxDecoration(
                color: Colors.grey[200],
              ),
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Center(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        children: [
                          IconButton(
                            icon: Icon(Icons.arrow_back, color: Colors.blue[900]),
                            onPressed: () => Navigator.of(context).pop(),
                          ),
                        ],
                      ),
                      SizedBox(height: 20.0),
                      Container(
                        padding: EdgeInsets.all(20.0),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Colors.blue[700]!, Colors.red[600]!],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(25.0),
                        ),
                        child: Text(
                          'Cadastre-se agora',
                          style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold, color: Colors.white),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      SizedBox(height: 20.0),
                      Container(
                        padding: EdgeInsets.all(20.0),
                        decoration: BoxDecoration(
                          color: Color(0xFF003366),
                          borderRadius: BorderRadius.circular(25.0),
                        ),
                        child: Form(
                          key: formKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              // Campos de entrada para nome, email, usuário e senha
                              Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: TextFormField(
                                  controller: nameController,
                                  decoration: InputDecoration(
                                    labelText: "Nome",
                                    hintText: "Digite seu nome.",
                                    prefixIcon: Icon(Icons.perm_identity_rounded),
                                    filled: true,
                                    fillColor: Colors.white,
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(25.0),
                                      borderSide: BorderSide.none,
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(25.0),
                                      borderSide: BorderSide(color: Colors.blue),
                                    ),
                                    contentPadding: EdgeInsets.symmetric(vertical: 16.0, horizontal: 12.0),
                                  ),
                                  validator: (String? value) {
                                    if (value == null || value.isEmpty) {
                                      return "Nome não pode ser nulo.";
                                    }
                                    return null;
                                  },
                                ),
                              ),
                              // Outros campos para email, usuário e senha seguem o mesmo padrão

                              Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: TextFormField(
                                  controller: emailController,
                                  decoration: InputDecoration(
                                    labelText: "E-mail",
                                    hintText: "Digite seu E-mail",
                                    prefixIcon: Icon(Icons.email),
                                    filled: true,
                                    fillColor: Colors.white,
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(25.0),
                                      borderSide: BorderSide.none,
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(25.0),
                                      borderSide: BorderSide(color: Colors.blue),
                                    ),
                                    contentPadding: EdgeInsets.symmetric(vertical: 16.0, horizontal: 12.0),
                                  ),
                                  validator: (String? value) {
                                    if (value == null || value.isEmpty) {
                                      return "E-mail não pode ser nulo.";
                                    }
                                    if (!value.contains("@")) {
                                      return "E-mail inválido.";
                                    }
                                    return null;
                                  },
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: TextFormField(
                                  controller: usernameController,
                                  decoration: InputDecoration(
                                    labelText: "Usuário",
                                    hintText: "Digite seu usuário.",
                                    prefixIcon: Icon(Icons.account_circle),
                                    filled: true,
                                    fillColor: Colors.white,
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(25.0),
                                      borderSide: BorderSide.none,
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(25.0),
                                      borderSide: BorderSide(color: Colors.blue),
                                    ),
                                    contentPadding: EdgeInsets.symmetric(vertical: 16.0, horizontal: 12.0),
                                  ),
                                  validator: (String? value) {
                                    if (value == null || value.isEmpty) {
                                      return "Usuário não pode ser nulo.";
                                    }
                                    return null;
                                  },
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: TextFormField(
                                  controller: passwordController,
                                  obscureText: true,
                                  decoration: InputDecoration(
                                    labelText: "Senha",
                                    hintText: "Digite sua senha.",
                                    prefixIcon: Icon(Icons.password),
                                    filled: true,
                                    fillColor: Colors.white,
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(25.0),
                                      borderSide: BorderSide.none,
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(25.0),
                                      borderSide: BorderSide(color: Colors.blue),
                                    ),
                                    contentPadding: EdgeInsets.symmetric(vertical: 16.0, horizontal: 12.0),
                                  ),
                                  validator: (String? value) {
                                    if (value == null || value.isEmpty) {
                                      return "Senha não pode ser nula.";
                                    }
                                    if (value.length < 6 || value.length > 8) {
                                      return "A senha precisa ter de 6-8 caracteres.";
                                    }
                                    return null;
                                  },
                                ),
                              ),
                              SizedBox(height: 10.0),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Checkbox(
                                    value: isTermsAccepted,
                                    onChanged: (bool? newValue) {
                                      setState(() {
                                        isTermsAccepted = newValue!;
                                      });
                                    },
                                  ),
                                  Text(
                                    'Li e concordo com os ',
                                    style: TextStyle(color: Colors.white),
                                  ),
                                  GestureDetector(
                                    onTap: _openTerms,
                                    child: Text(
                                      'Termos e Condições',
                                      style: TextStyle(
                                        color: Colors.blue,
                                        decoration: TextDecoration.underline,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 10.0),
                              // Parte do código da RegistrationScreen
                              Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: Container(
                                  width: double.infinity,
                                  child: ElevatedButton(
                                    onPressed: () {
                                      if (formKey.currentState!.validate() && isTermsAccepted) {
                                        setState(() {
                                          isLoading = true;
                                        });

                                        // Adiciona o usuário ao banco de dados
                                        userDatabase.addUser(User(
                                          name: nameController.text,
                                          email: emailController.text,
                                          username: usernameController.text,
                                          password: passwordController.text,
                                        ));

                                        // Navega para a tela de login após o cadastro
                                        Navigator.pushReplacement(
                                          context,
                                          MaterialPageRoute(builder: (context) => Login(userDatabase: userDatabase)),
                                        );
                                      } else if (!isTermsAccepted) {
                                        ScaffoldMessenger.of(context).showSnackBar(
                                          SnackBar(content: Text("Você precisa aceitar os termos!")),
                                        );
                                      }
                                    },
                                    style: ElevatedButton.styleFrom(
                                      padding: EdgeInsets.symmetric(vertical: 16.0),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(25.0),
                                      ),
                                    ),
                                    child: Text(
                                      "Cadastrar",
                                      style: TextStyle(fontSize: 16.0),
                                    ),
                                  ),
                                ),
                              ),

                              if (isLoading)
                                Center(
                                  child: Padding(
                                    padding: const EdgeInsets.all(10.0),
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2.0,
                                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class SuccessScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text(
          'Aqui vai a tela do curso que foi feita pela Júlia Dalanora',
          style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
